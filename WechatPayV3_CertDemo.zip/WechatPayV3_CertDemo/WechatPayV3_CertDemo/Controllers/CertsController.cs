﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Parameters;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using WechatPayV3_CertDemo.Models;

namespace WechatPayV3_CertDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CertsController : ControllerBase
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly string _serialNo = ""; //API V3证书序列号
        private readonly string _mchID = "";  //商户号
        private readonly string _apiCertPath = Directory.GetCurrentDirectory() + $"/Certs/apiclient_cert.p12";  //API证书路径
        private readonly string _certPwd = "";  //证书密码（微信默认是商户号）
        private readonly string _privateKey = ""; //API v3秘钥
        private readonly string _outPath = Directory.GetCurrentDirectory() + $"/Certs/Wechat/";  //API证书路径

        public CertsController(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        /// <summary>
        /// 通过接口 保存微信平台证书
        /// </summary>
        [HttpGet]
        [Route("save")]
        public async void SaveCerts()
        {
            try
            {
                #region 请求API获取证书

                string _certUrl = "https://api.mch.weixin.qq.com/v3/certificates";
                var request = new HttpRequestMessage(HttpMethod.Get, _certUrl);

                var client = _clientFactory.CreateClient("certificates");

                var auth = BuildAuthAsync("GET", "", new Uri(_certUrl).AbsolutePath);
                string value = $"WECHATPAY2-SHA256-RSA2048 {auth}";

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue(new ProductHeaderValue("wechatpayv3demo", "1.1.0")));

                client.DefaultRequestHeaders.Add("Authorization", value);

                var response = await client.SendAsync(request);

                string body = await response.Content.ReadAsStringAsync();

                var certs = JsonConvert.DeserializeObject<CertificatesRet>(body);  //证书列表

                #endregion

                #region 解密证书

                List<CertsModel> plainCerts = new List<CertsModel>();
                List<X509Certificate2> x509Certs = new List<X509Certificate2>();
                foreach (var item in certs.data)
                {
                    CertsModel model = new CertsModel()
                    {
                        SerialNo = item.serial_no,
                        EffectiveTime = item.effective_time,
                        ExpireTime = item.expire_time,
                        PlainCertificate = AesGcmDecrypt(item.encrypt_certificate.associated_data, item.encrypt_certificate.nonce, item.encrypt_certificate.ciphertext)
                    };

                    X509Certificate2 x509Cert = new X509Certificate2(Encoding.UTF8.GetBytes(model.PlainCertificate));

                    x509Certs.Add(x509Cert);
                    plainCerts.Add(model);

                }

                #endregion

                #region 签名校验

                string message = await buildMessage(response);
                string serial = response.Headers.GetValues("Wechatpay-Serial").FirstOrDefault();
                string signature = response.Headers.GetValues("Wechatpay-Signature").FirstOrDefault();

                var cert = x509Certs.Where(r => r.SerialNumber == serial).FirstOrDefault();  //根据序列号获取证书

                byte[] data = Encoding.UTF8.GetBytes(message);

                var rsaParam = cert.GetRSAPublicKey().ExportParameters(false);
                var rsa = new RSACryptoServiceProvider();
                rsa.ImportParameters(rsaParam);

                var isOk = rsa.VerifyData(data, CryptoConfig.MapNameToOID("SHA256"), Convert.FromBase64String(signature));  //签名校验

                if (!isOk)
                {
                    return;
                }

                #endregion

                #region 保存证书文件

                SaveCerts(plainCerts);  //保存证书文件

                #endregion

            }
            catch (Exception ex)
            {

            }
        }

        protected void SaveCerts(List<CertsModel> plainCerts)
        {
            var info = Directory.CreateDirectory(_outPath);

            foreach (var item in plainCerts)
            {
                string fileFullName = info.FullName + "wechatpay_" + item.SerialNo + ".pem";

                using (var fileStream = new FileStream(fileFullName, FileMode.Create, FileAccess.Write))
                {
                    byte[] data = Encoding.ASCII.GetBytes(item.PlainCertificate);

                    fileStream.Write(data, 0, data.Length);
                }
            }
        }


        protected async Task<string> buildMessage(HttpResponseMessage response)
        {
            string timestamp = response.Headers.GetValues("Wechatpay-Timestamp").FirstOrDefault();
            string nonce = response.Headers.GetValues("Wechatpay-Nonce").FirstOrDefault();
            string body = await response.Content.ReadAsStringAsync();
            return timestamp + "\n"
                    + nonce + "\n"
                    + body + "\n";
        }

        protected string BuildAuthAsync(string method, string body, string uri)
        {
            var timestamp = DateTimeOffset.Now.ToUnixTimeSeconds();
            string nonce = Path.GetRandomFileName();

            string message = $"{method}\n{uri}\n{timestamp}\n{nonce}\n{body}\n";
            string signature = RequestSign(message);
            return $"mchid=\"{_mchID}\",nonce_str=\"{nonce}\",timestamp=\"{timestamp}\",serial_no=\"{_serialNo}\",signature=\"{signature}\"";
        }

        protected string RequestSign(string message)
        {
            X509Certificate2 cer = new X509Certificate2(_apiCertPath, _certPwd, X509KeyStorageFlags.Exportable);  //加载证书
            if (cer != null)
            {
                RSA rsa = cer.GetRSAPrivateKey();  //获取私钥
                //查看在不同平台上的具体类型
                byte[] data = Encoding.UTF8.GetBytes(message);
                return Convert.ToBase64String(rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1));
            }
            else
            {
                return ""; ;
            }
        }

        /// <summary>
        /// 证书/回调报文解密
        /// </summary>
        /// <param name="associatedData"></param>
        /// <param name="nonce"></param>
        /// <param name="ciphertext"></param>
        /// <returns></returns>
        protected string AesGcmDecrypt(string associatedData, string nonce, string ciphertext)
        {
            GcmBlockCipher gcmBlockCipher = new GcmBlockCipher(new AesEngine());
            AeadParameters aeadParameters = new AeadParameters(
                new KeyParameter(Encoding.UTF8.GetBytes(_privateKey)),
                128,
                Encoding.UTF8.GetBytes(nonce),
                Encoding.UTF8.GetBytes(associatedData));
            gcmBlockCipher.Init(false, aeadParameters);

            byte[] data = Convert.FromBase64String(ciphertext);
            byte[] plaintext = new byte[gcmBlockCipher.GetOutputSize(data.Length)];
            int length = gcmBlockCipher.ProcessBytes(data, 0, data.Length, plaintext, 0);
            gcmBlockCipher.DoFinal(plaintext, length);
            return Encoding.UTF8.GetString(plaintext);
        }
    }
}
